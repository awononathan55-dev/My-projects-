/* Simple calculator logic */
const historyEl = document.getElementById('history');
const resultEl = document.getElementById('result');
const keys = document.querySelectorAll('.btn');

let expression = ''; // internal expression using JS operators (*, /, +, -, %)
let lastResult = null;

function updateDisplay(){
  historyEl.textContent = expression;
  resultEl.textContent = expression === '' ? '0' : expression;
}

function appendValue(val){
  // prevent multiple dots in the current number
  if(val === '.'){
    const lastOp = Math.max(
      expression.lastIndexOf('+'),
      expression.lastIndexOf('-'),
      expression.lastIndexOf('*'),
      expression.lastIndexOf('/'),
      expression.lastIndexOf('%')
    );
    const lastNumber = expression.slice(lastOp + 1);
    if(lastNumber.includes('.')) return;
    if(lastNumber === '') {
      expression += '0'; // start number with 0.
    }
  }

  // prevent consecutive operators (replace last operator)
  if(['+','-','*','/','%'].includes(val)){
    if(expression === '' && val !== '-') {
      // don't allow starting with operator except minus (negative numbers)
      return;
    }
    const lastChar = expression.slice(-1);
    if(['+','-','*','/','%'].includes(lastChar)){
      // replace last operator with new one
      expression = expression.slice(0, -1) + val;
      updateDisplay();
      return;
    }
  }

  expression += val;
  updateDisplay();
}

function clearAll(){
  expression = '';
  lastResult = null;
  updateDisplay();
}

function deleteLast(){
  expression = expression.slice(0, -1);
  updateDisplay();
}

function compute(){
  if(expression === '') return;
  try{
    // handle % as division by 100 when used as a suffix or operator:
    // We'll transform standalone "number%" into "(number/100)"
    // Simple replacement using regex to convert e.g. "50%" -> "(50/100)"
    const transformed = expression.replace(/(\d+(\.\d+)?)%/g, '($1/100)');
    // Use Function constructor (safer than eval in this limited context)
    const value = Function(`"use strict"; return (${transformed})`)();
    if(!isFinite(value)) throw new Error('Result is not finite');
    lastResult = value;
    expression = parseFloat(String(value));
    updateDisplay();
    historyEl.textContent = expression;
  }catch(e){
    resultEl.textContent = 'Error';
    console.error('Compute error:', e);
    expression = '';
  }
}

keys.forEach(btn => {
  btn.addEventListener('click', () => {
    const val = btn.getAttribute('data-value');
    const action = btn.getAttribute('data-action');
    if(action === 'clear'){ clearAll(); return; }
    if(action === 'delete'){ deleteLast(); return; }
    if(action === 'equals'){ compute(); return; }
    if(val) appendValue(val);
  });
});

// keyboard support
document.addEventListener('keydown', (e) => {
  const key = e.key;
  if((/^[0-9]$/).test(key)) appendValue(key);
  else if(key === '.') appendValue('.');
  else if(key === 'Enter' || key === '='){ e.preventDefault(); compute(); }
  else if(key === 'Backspace') deleteLast();
  else if(key === 'Escape') clearAll();
  else if(key === '+') appendValue('+');
  else if(key === '-') appendValue('-');
  else if(key === '*' || key === 'x') appendValue('*');
  else if(key === '/') appendValue('/');
  else if(key === '%') appendValue('%');
});

// initialize
updateDisplay();